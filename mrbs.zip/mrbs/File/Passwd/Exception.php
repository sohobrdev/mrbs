<?php
class File_Passwd_Exception extends Exception {}